# Contributing to EducationOS

Use an issue and branch; open a PR with evidence and safety review. Keep a source of truth in `docs/`, structured code in `apps/` and contracts in `packages/`. All education-content changes include stage, pedagogy, evidence rubric, review and immutable version identifiers. Never commit real child personal data, tokens, secrets or unlicensed assets. Follow Conventional Commits and update governance/CHANGELOG.md for material changes. Refer to docs/13_engineering_and_versioning.md and docs/18_definition_of_done.md.
