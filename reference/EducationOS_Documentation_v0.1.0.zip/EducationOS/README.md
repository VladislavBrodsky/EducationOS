# EducationOS — Foundation Architecture & Product Specification

**Documentation release:** `v0.1.0` · **Status:** Architecture proposal / not implemented · **As of:** 2026-10-17

> EducationOS is a safe, mastery-visible, TRIZ-informed learning platform for children and teens aged **5–17**, with adult guardian, educator, editor, and school-administrator experiences. An adult learner track (18+) is not in initial scope; it could be a future separate product segment.

## North star
Empower learners to **notice → question → model → invent → test → explain → transfer**, not merely watch content or chase scores. Deliver developmentally appropriate storytelling, age-based learning routes, real-world missions, and a private Skills Vault backed by tangible evidence.

## READ FIRST — product decisions
1. Five age stages: Explorers (5–6), Builders (7–9), Makers (10–12), Creators (13–15), Launchers (16–17). Ability-based differentiation *within* a stage; no simplistic ability tracking from age.
2. One modular monolith at launch; separate deployable web, API and worker, **one shared PostgreSQL source of truth**, asynchronous jobs and an outbox, not premature microservices.
3. The referenced Refero **Steep** system and image-set lime-green EducationOS aesthetic conflict; use a **shared system with editorial and discovery themes** rather than claiming they match.
4. Parent-managed / school-authorized identities with legally appropriate consent; no public child profiles, open chat, targeted advertising, or unrestricted generative AI.
5. Progress is an interpreted, confidence-rated view over evidence; never initialize every learner to invented percentages or present mocked ARR as fact.
6. Progressive shipping: a web-first vertical slice; native AR glasses, social feed, B2B procurement, and fully autonomous AI tutoring are later research workstreams, not launch promises.
7. Every content item, evidence rubric, policy, schema, API, model configuration, prompt, and document is versioned.

## Documentation map
| Document | Purpose |
|---|---|
| [01 — Visual audit](docs/01_visual_audit.md) | Every reference slide, actionable gaps, design reconciliation |
| [02 — PRD](docs/02_product_requirements.md) | Users, JTBD, scope, capabilities, non-goals, success |
| [03 — Information architecture](docs/03_information_architecture.md) | User flows, products, and navigation |
| [04 — TRIZ research](docs/04_triz_research.md) | Theory, accurate methods, age application, 40 principles |
| [05 — Curriculum](docs/05_curriculum_framework.md) | Domains, skills, five-stage scope and sequence |
| [06 — Story worlds](docs/06_storytelling_universe.md) | Worldbuilding, quests, tone, motivation, character bible |
| [07 — Mastery](docs/07_assessment_and_mastery.md) | Competency graph, evidence, rubrics, progression |
| [08 — System architecture](docs/08_system_architecture.md) | C4-like context/components, deployment and failure domains |
| [09 — Data architecture](docs/09_data_architecture.md) | Entities, tenancy, retention, event patterns |
| [10 — API design](docs/10_api_contracts.md) | Endpoints, permissions, contracts and versions |
| [11 — Child protection](docs/11_privacy_and_safety.md) | COPPA/GDPR considerations, threat model, controls |
| [12 — Design system](docs/12_design_system.md) | Steep reference, EducationOS themes, tokens, components |
| [13 — Delivery](docs/13_engineering_and_versioning.md) | Git, CI/CD, versioning, SLO, testing and change control |
| [14 — Roadmap](docs/14_roadmap_and_team.md) | Phased milestones, staffing, acceptance gates |
| [15 — GTM](docs/15_business_and_measurement.md) | Ethical economics, measurable learning, no invented figures |
| [16 — Evidence and sources](docs/16_sources_and_assumptions.md) | Bibliography, assumptions, decisions to validate |
| [17 — Content production](docs/17_content_governance.md) | Author/review/publish, content safety and localization |
| [18 — Testing & acceptance](docs/18_definition_of_done.md) | Product, platform, safety and pedagogy quality gates |
| [19 — AI architecture](docs/19_ai_system_design.md) | AI gateway, grounded tutor, evaluation and risk controls |
| [ADRs](docs/adr) | Architecture decision records |

**This package contains planning documentation only.** No production UI, API, database, AR experience, identity, consent implementation or payments have been built. Directories reserved for future development do not imply runnable prototypes exist.

## Operational documentation
- [Changelog](governance/CHANGELOG.md), [decisions register](governance/DECISIONS.md), [risk register](governance/RISK_REGISTER.md), [contributing](CONTRIBUTING.md), and [security](SECURITY.md).

## Deliverable quality and honesty
This is a researched architecture and design foundation—not a deployed system, validated curriculum, security certification, production-ready auth service, legal opinion, or demonstrated educational outcome. Sources and uncertainties are explicit.

## Repository discipline
- Documentation baseline version `0.1.0` (proposed; no Git tag or published application release yet)
- Product/documentation semantic releases: `MAJOR.MINOR.PATCH`; content and rubrics have independent immutable versions; migrations are forward-only.
- Follow conventional commits, protected branches, pull requests, ADRs, CI checks, and CHANGELOG updates.
- Target repository: https://github.com/VladislavBrodsky/EducationOS . As of this export, writing via the GitHub integration returned HTTP 403, so these files have **not** been committed. This package is ready for review and import when repository permissions are corrected.

## Immediate decisions requested from founder
**Markets/jurisdictions**, launch languages, whether adult courses belong to the same brand or a later platform, initial launch stage(s), school-first versus family-first, curriculum alignment markets, accessibility/learner-needs priorities, initial budget and timeline, and whether licensed proprietary fonts/illustrations are available. See the assumptions register.
