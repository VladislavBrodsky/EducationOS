# Changelog

All notable changes to EducationOS planning, schemas and software will be documented here. The following baseline is **draft documentation**, not an application release or Git tag.

## [0.1.0] — 2026-10-17 (proposed)
- Founded documentation baseline: product thesis, visual audit, TRIZ, curriculum, storytelling, assessment, architecture, AI policy, child protection, design-system and phased roadmap.
- Distinguished proposed capabilities, educational hypotheses, real evidence and future R&D.
- Set release governance, review requirements and decision records.
