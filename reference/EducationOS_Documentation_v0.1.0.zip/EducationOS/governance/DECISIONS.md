# Founder decisions register

| ID | Decision to be made | Default for planning only | Owner | Status |
|---|---|---|---|---|
| D-001 | Initial country/legal market | None | CEO / counsel | Open |
| D-002 | Launch age cohort | Pilot 7–9 or 10–12 first | CEO + learning lead | Open |
| D-003 | Initial language(s) | English plus one market language | CEO | Open |
| D-004 | Consumer vs school entry | Guardian-led B2C hypothesis | CEO + growth | Open |
| D-005 | First special program | Inventors Academy | Head of Learning | Open |
| D-006 | Technology framework/provider | TypeScript / PostgreSQL modular monolith | CTO | Proposed |
| D-007 | Child privacy and school role | Jurisdiction-specific counsel determination | Legal | Open |
| D-008 | Budget and hiring | Stage-gated lean team | CEO | Open |
| D-009 | AR software/hardware | Defer proprietary hardware | CEO + CTO | Proposed |
| D-010 | Design reference reconciliation | Editorial + Discovery themes | Design lead | Proposed |
