# Risk register

| Risk | Severity | Early signal | Mitigation | Owner |
|---|---|---|---|---|
| Child data breach or unsafe AI response | Critical | permission-test failures or moderation defects | strict release gates, human review, threat model, kill switch | CTO/safeguarding |
| TRIZ curriculum perceived as gimmicky | High | weak transfer assessments | educator research, calibrated rubrics, real projects | Head of Learning |
| High-content production cost | High | author hours per mission above plan | reusable authoring primitives and staged domains | Product/Learning |
| Low willingness to pay | High | paid pilot opt-in weak | narrow ICP, pricing tests, adult interviews | CEO/Growth |
| Poor accessibility for ages 5–6 | High | unable to complete flows without prompting | co-design, audio, reduced complexity and offline mode | Design lead |
| Overengineering of AR hardware | Critical | burn without validated 2D/AR educational lift | deferred hardware and separate investment case | CEO/CTO |
| Unverified pitch metrics | High | partner/investor diligence questions | treat all examples as illustrative | CEO/Finance |
| School sales procurement drag | Medium | >6 month negotiations | B2C wedge; pilot proof; security documentation | Business lead |
