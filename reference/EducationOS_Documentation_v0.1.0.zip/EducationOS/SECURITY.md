# Security and safeguarding

This is an early planning repository and does not represent a launched child-facing service. **Do not include real minors’ personal information in issues, PRs or code.** Report a suspected security/privacy issue to the repository owner privately using GitHub's private vulnerability reporting feature where enabled; avoid publishing details publicly. Operational safeguarding contact, incident response channel and report SLAs must be established before pilot release.
