## Summary

## Motivation and linked issue

## What changed

## Acceptance evidence / screenshots / tests

## Child safety, privacy, accessibility, pedagogy impact
- [ ] No child data included in code, screenshots or fixtures
- [ ] Consent/role and cross-tenant implications reviewed
- [ ] Accessibility evaluated
- [ ] Scientific/curriculum review completed where relevant
- [ ] AI evals completed where relevant

## Docs, CHANGELOG and rollback

## Reviewer(s)
