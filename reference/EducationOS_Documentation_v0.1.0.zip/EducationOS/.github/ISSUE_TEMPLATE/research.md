---
name: Research
about: Test a learning, product or business hypothesis
---

## Hypothesis
## Research population / consent
## Method and predeclared success criterion
## Biases and limitations
## Evidence to collect and retention
## Decision date and accountable owner
