---
name: Feature
about: Propose measurable product capability
---

## User/problem (age and adult supervision)
## Evidence this problem matters
## Expected learner capability
## Acceptance criteria
## Accessibility and safe offline alternative
## Security/privacy and consent implications
## Dependencies and owner
## Definition of done
