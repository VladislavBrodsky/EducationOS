# 19 · AI tutoring and creative co-invention system

**Version:** 0.1.0 | **Status:** future implementation specification.

## Role of AI
An interactive **questioning and modeling assistant** grounded in educator-reviewed curriculum—not an unrestricted friend/therapist or replacement educator. It should challenge learners to generate multiple hypotheses, invite counterexamples, expose hidden assumptions, and recommend safe offline experiments; not deliver a single authoritative answer or build dependency.

## Pipeline
Guardian/school authorization → identity, age and context policy → input moderation and PII minimization → lesson/version-grounded retrieval → structured tool with approved templates → output policy, factual/safety checks → age-appropriate response → event logging with private-data minimization and evaluation sampling → teacher/guardian review surfaces. Separate policy engine from LLM text instructions. No provider-side training on child data without legally and ethically sound authorization.

## AI product rules
Model cannot solicit identifying information, private chats, photographs, location, contact details or off-platform connections. Never suggest dangerous chemical/physical experiments or financial/medical advice. For a minor, no open web browsing, unchecked code execution or arbitrary tool access; keep sandbox constrained. Show a clear 'I don't know' response and offer a trusted-adult handoff.

## Quality and evaluation
Golden tests across ages, languages and domains; factuality, unsupported confidence, TRIZ method fidelity, divergent idea originality without nonsense, solution diversity, accessibility, refusal correctness, unsafe content, PII leakage and educator override quality. Establish offline evals before feature flags/online use; track errors and model costs per learning outcome, not chat turns.
