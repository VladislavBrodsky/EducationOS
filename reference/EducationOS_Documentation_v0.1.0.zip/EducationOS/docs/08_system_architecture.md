# 08 · System architecture (modular-monolith-first)

**Version:** 0.1.0 | **Status:** target blueprint, not deployed.

## Decisions
- **Web first:** Next.js + React + TypeScript; age-adaptive design system, server-rendered marketing pages and accessible web app. Native mobile deferred until validated demand.
- **API:** TypeScript Node.js/NestJS (or Fastify modular services) with REST/OpenAPI. Select one framework in an ADR after a thin spike; avoid running two backends.
- **Database:** managed PostgreSQL, row-scoped authorization, migrations and backups; `pgvector` only when retrieval use cases are validated. Redis for rate limiting and bounded cache; object storage for vetted artifacts.
- **Async:** transactional outbox + one worker queue for email, content indexing, AI moderation and scheduled recalculation. Async failures must be idempotently retryable.
- **Ops:** managed cloud environment (region selected after residency/compliance review), IaC, WAF, CDN, identity provider, KMS, Secrets Manager, OpenTelemetry telemetry, error tracker. No single-cloud requirement until cost/security discovery.
- **AI:** provider-agnostic AI gateway behind server API; no direct browser model credentials; age policies, knowledge grounding, redaction, prompt/config versioning, human review and evaluation suite.

## Context diagram
```mermaid
flowchart TD
  Guardian[Guardian / teacher] --> Web[Responsive web]
  Learner[Learner] --> Web
  Web --> API[Modular monolith API]
  API --> Auth[Identity and consent]
  API --> Postgres[(PostgreSQL)]
  API --> Storage[(Encrypted object storage)]
  API --> Outbox[(Outbox / jobs)]
  Outbox --> Worker[Worker]
  Worker --> AI[AI gateway and policy filter]
  Teacher[Curriculum editor] --> CMS[Private content authoring]
  CMS --> API
  API --> Metrics[Privacy-first analytics]
```

## Logical modules
`identity`, `consent`, `tenancy`, `profiles`, `catalog`, `skills`, `missions`, `attempts`, `evidence`, `assessment`, `portfolio`, `billing`, `guardian`, `educator`, `AI-safety`, `content-moderation`, `events`, `admin`. Each module owns interfaces and tables; cross-module writes happen through application services, not arbitrary table access. Tenant boundaries are tested on every resource type.

## API perimeter
Public: marketing, public program metadata. Authenticated guardian: enrollments, consents, invoices, child's private progress. Learner: own permitted missions, submissions, feedback. Educator: scope-limited cohorts, review evidence. Internal editorial: staged/published content. No public child discovery API. API version `/v1`, OpenAPI checked in CI; mutation endpoints idempotency keys where appropriate.

## Quality targets (engineering hypotheses, not measured)
Availability aim 99.9% after stable paid launch; accessible baseline WCAG 2.2 AA; P95 interactive API under 500ms for non-AI endpoints at target pilot load; explicit AI latency UX; encrypted transit/rest; minimum necessary logging and data retention. Verify via SLO burn alerts, restore drills, penetration tests and load tests before public launch.

## Threat model checklist
Unauthorized child-data access, cross-tenant leaks, prompt injection, model hallucination, inference of sensitive attributes, malicious file upload, school SSO misuse, excessive retention, insider bulk export, scraping, payment fraud and unsafe maker instructions. Validate controls before scaling.
