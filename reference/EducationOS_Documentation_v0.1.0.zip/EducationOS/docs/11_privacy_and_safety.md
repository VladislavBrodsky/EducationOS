# 11 · Child protection, privacy and AI safety

**Version:** 0.1.0 | **Status:** requirements baseline only; legal counsel and jurisdictional review required.

## Non-negotiable gates
1. Choose launch jurisdictions and legal role (controller/processor) before accepting child data.
2. COPPA for relevant US under-13 flows; state privacy rules also apply. EU GDPR and member-state digital consent age; UK Children’s Code and UK GDPR; FERPA when education records are processed for qualifying US schools. Validate locally.
3. Age-assurance with minimal collection; verify guardian authority using legally appropriate methods. Consent must be purpose-specific, logged, revocable and reflected in downstream jobs and vendors.
4. Default private learner profiles; no public social network, unrestricted DMs, behavioral advertising or adult/minor matching.
5. AI: age-graded prompting, bounded topics, whitelist content retrieval, harmful-output controls, human escalation and safe fallback. AI never independently diagnoses, counsels, grades high-stakes work or instructs hazardous experiments.
6. Vendor DPA, subprocessor list, model-data use controls, privacy impact assessment, threat modeling and full delete/export workflows.
7. Safeguarding policy with trained responsible staff, escalation matrix, incident response and school/guardian communications.
8. Accessibility and universal design from discovery; WCAG 2.2 AA audit, screenreader/keyboard checks, low-vision support, captions and reading accommodations.
9. Security: MFA for adults/admins, least privilege, encryption, secrets rotation, audit, backup restore, dependency/pentest checks, vulnerability disclosure.

## Release gate: child-safe MVP
The release cannot enroll real children until jurisdiction-specific assessment and consent/identity implementation pass an independent review, appropriate legal documents are published, incident contacts are staffed, data retention/deletion is exercised and all high-severity findings are remediated. Use synthetic accounts for prototypes.

## Regulatory references for counsel
- FTC COPPA Rule: https://www.ftc.gov/business-guidance/privacy-security/childrens-privacy
- EU GDPR Article 8: https://eur-lex.europa.eu/eli/reg/2016/679/oj
- UK Age Appropriate Design Code: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/childrens-information/childrens-code-guidance-and-resources/
- US FERPA: https://studentprivacy.ed.gov/ferpa
- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/
