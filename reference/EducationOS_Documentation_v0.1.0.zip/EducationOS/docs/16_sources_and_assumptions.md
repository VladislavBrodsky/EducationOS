# 16 · Sources, validation needs and assumptions

**Version:** 0.1.0 | **Status:** bibliography for verification, not a substitute for deep research or legal review.

## Relevant primary material and standards
- MATRIZ official wiki: https://wiki.matriz.org/docs/triz/ ; matrix, contradictions, IFR and ARIZ subpages are referenced in [04](04_triz_research.md).
- FTC COPPA guidance: https://www.ftc.gov/business-guidance/privacy-security/childrens-privacy
- EU GDPR text: https://eur-lex.europa.eu/eli/reg/2016/679/oj
- UK Children’s Code: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/childrens-information/childrens-code-guidance-and-resources/
- FERPA: https://studentprivacy.ed.gov/ferpa
- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/
- 1EdTech CASE specifications (standards mapping): https://www.1edtech.org/standards/case
- 1EdTech LTI (future school integrations): https://www.1edtech.org/standards/lti
- W3C WebXR (future software-only immersive work): https://www.w3.org/TR/webxr/
- Refero stylistic inspiration: https://styles.refero.design/style/75fdb89f-ca64-41b3-af36-7a78bd09448e

## Truthfulness rules
No claim of TRIZ superior efficacy for all ages without studies; no claim that EducationOS has achieved retention/ARR/skill scores shown in pitch images; no assertion of COPPA/GDPR certification; no claim of implemented and tested architecture. Source links and claims should be reverified before external investor or educator publication.

## Explicit assumptions to resolve
Markets, jurisdictions, languages, degree of parental supervision, launch wedge age group, whether adult learning becomes separate product, curriculum standards, willingness to pay, content production cost, local legal counsel, AI vendor usage policy, personal-data retention, AR accessibility and long-horizon hardware unit economics.
