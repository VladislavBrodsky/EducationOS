# 14 · Phased development roadmap and operating plan

**Version:** 0.1.0 | **Status:** planning hypotheses. Durations are *relative from project kickoff*; gates may extend timelines.

## Critical path and stage gates
| Phase | Indicative window | Outcomes | Release gate |
|---|---|---|---|
| 0: Strategy + validation | Weeks 1–4 | 25–40 guardian/educator interviews, 5–10 learner co-design sessions with consent, jurisdiction, market and wedge decision | Written evidence that a narrow learner problem deserves solving; consent/safeguarding research plan |
| 1: Pedagogy and product blueprint | Weeks 3–8 | Skills taxonomy v1, TRIZ curriculum archetypes, 6–12 missions, outcome rubric, narrative bible, PRD, design tokens | Educator review and usability test with target age; assessment rubric works offline |
| 2: Secure platform skeleton | Weeks 6–12 | Web app, API, DB, adult authentication, approved child identities, RBAC, consent, observability, deployment pipeline | Threat model + access-boundary tests + baseline a11y and incident playbook |
| 3: Vertical-slice MVP | Months 3–5 | 1 cohort, 1 special program, 8–12 polished missions, submissions, feedback, private Skills Vault and parent summary | Complete learner journey, human-reviewed evidence, no critical privacy/safety findings |
| 4: Closed pilots | Months 5–7 | 30–100 opt-in families and/or 2–4 partners, structured pre/post studies, moderation/support | Pilot thresholds agreed **before** testing, satisfaction and learning quality investigated |
| 5: Paid narrow launch | Months 7–10 | Guardian billing, subscription hypothesis, lifecycle support, onboarding, acquisition funnel | Payment, refunds, tax, consent, safeguarding, support and operational readiness reviewed |
| 6: Optimize product and growth | Months 9–15 | More programs, cohort reliability, adult-owned referral system, curriculum operations, efficiency | Repeat use + credible learner outcomes + safe unit economics, not vanity DAU |
| 7: B2B and localization | Months 12–24 | Teacher tools, safe school pilot, standards mapping, localization, procurement and SSO when validated | School security/privacy review and real paid demand |
| 8: Spatial education software | Months 18–30 | Web 3D, optional tablet AR and mixed reality experiments for physics/engineering | Measured learning advantage vs 2D + hardware access + safety review |
| 9: Proprietary AR/VR hardware R&D | Months 30+ | Optical/ergonomic feasibility, engineering prototypes, vendor and regulatory diligence | Separate capital plan + compelling educational differentiation + safety/legal feasibility |

Phases 1 and 2 may overlap after Phase 0 guardrails. Do not parallelize risky child-data operations ahead of consent review. Phases 8–9 are **optional**, not promised commitments.

## First 12 weeks
- **Weeks 1–2:** decide ICP, geography, languages, budget; recruit pedagogy and privacy advisors; open interview tracker and decisions register.
- **Weeks 3–4:** run interviews and observation; prioritize stage 7–9 **or** 10–12 via evidence; choose ONE exemplar special program.
- **Weeks 5–6:** author 3 TRIZ challenge families with age adaptations; test paper prototypes, narrative hooks and rubric scoring.
- **Weeks 7–8:** finalize PRD v1, Figma tokens, API boundary ADRs, threat model, schema and first vertical slice.
- **Weeks 9–10:** implement one guardian-to-learner-to-review flow with fake/test data, tests and accessibility.
- **Weeks 11–12:** private expert QA, pilot protocol approval, content production checklist and launch go/no-go report.

## Example workstreams and accountability
| Workstream | Accountable owner | Contributors |
|---|---|---|
| Positioning/fundraising | CEO | PM, growth, advisors |
| Learning quality and standards | Head of Learning | Curriculum experts, teacher reviewers |
| Data protection/safeguarding | Privacy/safeguarding lead | Counsel, CTO, trust & safety |
| System/AI/security | CTO | Tech lead, backend, frontend, infra |
| Learner experience | Product lead | Design, research, learning scientists |
| Content/story worlds | Creative director | Curriculum writers, illustrators |
| Monetization / distribution | Growth/business lead | CEO, community, school partnerships |

## Monthly cadence
Weekly cross-functional demo, two-week sprint planning and retrospective, monthly product/safety/learning review, quarterly strategy and budget review. Record owners, evidence, decisions and risks. **Do not hire a large team or launch many domains before first validated learning loop.**
