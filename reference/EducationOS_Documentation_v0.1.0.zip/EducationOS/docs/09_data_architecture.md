# 09 · Data architecture and knowledge graph

**Version:** 0.1.0 | **Status:** conceptual.

## Core relational schema
`tenants`, `users` (adult or child role, age-band only as required), `guardian_learner_links`, `consent_records`, `educator_rosters`, `curriculum_frameworks`, `domains`, `competencies`, `competency_versions`, `prerequisite_edges`, `programs`, `program_versions`, `missions`, `mission_versions`, `mission_objectives`, `content_blocks`, `attempts`, `submissions`, `evidence_artifacts`, `rubric_versions`, `assessment_judgements`, `mastery_snapshots`, `events`, `ai_evaluations`, `subscription_accounts`, `audit_log`, `erasure_requests`.

## Hard rules
- Stable opaque UUIDs; relational constraints; safe table naming and documented retention.
- Every user-data table scoped to tenant and/or authenticated actor; verify security with automated negative tenant-access tests.
- Published curricula and rubric versions immutable; keep explicit supersedes links and deterministic migration plans.
- `mastery_snapshots` are derived with provenance and recalculable; never the sole source of truth.
- Object artifacts stored encrypted with expiring signed access; use private buckets, MIME allowlists, scanning and EXIF removal.
- Event tracking only for approved purposes; no unrestricted behavioral surveillance of minors, ad targeting or user-level cross-product data sales.
- Database backups include restoration tests, retention restrictions and access logs.

## Knowledge graph approach
Represent initial skill nodes + prerequisite edges in PostgreSQL, query recursively for small graphs, and create precomputed adjacency tables/materialized views if needed. Do **not** deploy Neo4j/GraphQL federation by default. Split off graph infrastructure only if measured queries, authoring workflow or scaling needs demand it.

## Version contracts
Data schema migration ID, mission version ID, rubric version ID, standards mapping revision, and AI prompt version should be present in evidence events. No retroactive silent rewrites of published learner experience.
