# 10 · API contracts and integration plan

**Version:** 0.1.0 | **Status:** proposed endpoints, not yet implemented.

## HTTP contracts
`GET /v1/me` authenticated identity; `GET /v1/catalog/programs` audience-filtered catalog; `GET /v1/learners/{id}/path` authorized stage-aware path; `POST /v1/missions/{id}/attempts` start a version-pinned attempt; `POST /v1/attempts/{id}/evidence` submit private artifact; `GET /v1/learners/{id}/skills` derived skill vault; `POST /v1/guardian/consents` auditable purpose-scoped consent; `GET /v1/educators/cohorts/{id}` authorized roster; `POST /v1/editorial/missions/{id}/publish` with required review gate; `POST /v1/ai/tutor-turn` contextual, policy-gated output.

## Request invariants
Identity and object-level authorization on **every** request; tenant constraints enforced server side. Validate inputs via schema, protect against IDOR and mass assignment, apply adaptive rate limits. `X-Request-ID` correlation, versioned content identifiers, reliable error codes, paging, size/timeout limits. Idempotency token on payment and submission mutations.

## Integrations
Checkout via mature hosted payments and guardian billing; tax/legal gates before launch. School rostering and SSO (OneRoster / LTI where appropriate) **after** school pilot demand is proven. Offline support and 3D/AR rendering via progressively enhanced client layers; prohibit unsafe unrestricted device sensors for minors.

## Contract checks
Generate OpenAPI from source, lint operation IDs and auth descriptions, validate breaking changes in CI, test with consumer mocks, execute negative authorization suites and per-age policy fixtures. No client secret or private learner data in telemetry.
