# 17 · Educational content governance

**Version:** 0.1.0 | **Status:** proposed.

## Publish pipeline
Draft story objective → map competency/version → author age-appropriate script → apply TRIZ/inquiry tool with instructional rationale → draft project and safe off-screen alternatives → create rubric/evidence types → expert scientific/pedagogical fact check → child safety and rights review → accessible/localized QA → small-group usability → publish immutable mission version → post-launch incident/learning monitoring → deprecate with change notice.

## Required mission manifest
`mission_id`, `version`, `stage`, `duration`, `competencies`, `triz_depth`, `intro_hook`, `story_world`, `contradiction`, `materials`, `hazards`, `supervision_level`, `offline_alternative`, `accessibility_modes`, `teacher_notes`, `steps`, `evidence_requirements`, `rubric_version`, `source_refs`, `reviewer_signoff`, `publication_status`.

## Critical controls
No hazardous improvisation suggestions; experiments require verified safe materials; child data examples use synthetic content; protect personal data in submissions; ensure permission to reuse art/fonts/text; update translations when curriculum changes and assess reading level with human review.
