# 07 · Assessment, evidence and mastery policy

**Version:** 0.1.0 | **Status:** proposed assessment framework; no validated outcomes yet.

## North star
**Weekly Evidence-Backed Capabilities Demonstrated (WECD)**: distinct learners who complete a reviewable, appropriately calibrated demonstration of a target capability within a seven-day period. Report along with denominator and quality metrics; guard against incentivizing easy evidence generation. Pair with learner wellbeing, safety, transfer and accessibility metrics.

## Skill claim ≠ mastery
A skill claim must include competency ID + competency version, observable performance objective, age context, rubric ID + version, artifact or signed observation reference, assessor (human or controlled AI assist), date, confidence, feedback and consent/retention policy. Single quizzes and passive content views do not prove mastery.

## Four-dimension rubric (sample)
| Dimension | Emerging | Developing | Applying | Transferring |
|---|---|---|---|---|
| Problem framing | Needs prompts to identify goal | States goal | States goal and constraints | Reframes and recognizes conflicting stakeholders |
| Divergent solutions | Offers one idea | Offers two | Explains 3 distinct strategies | Explores non-obvious strategies and trade-offs |
| Evidence/testing | Makes unsupported claims | Observes result | Uses fair, reproducible comparisons | Evaluates limitations, uncertainty and rival explanations |
| Reflection/transfer | Retells answer | Identifies change | Revises design | Applies principle in materially new context |

**Rules:** Rubric descriptors must be adapted for age and accessibility; accommodations cannot automatically lower core learning standards. Human override with rationale, appeals, provenance and calibration sampling. Mastery labels never claim precision unsupported by evidence. Store raw evidence separately from evaluated conclusions; re-evaluate when rubric changes.

## Skills Vault and permissions
Only the learner and appropriately authorized guardians/educators access private progress. Pseudonymous cohort aggregates may be used after applicable privacy review. Public portfolio sharing is disabled by default and requires granular consent and moderation. Learners may request corrections/deletion as required.

## Validation
Pre/post authentic tasks, blinded double-scoring subset, inter-rater agreement, transfer test after delayed interval, opt-out monitoring, missing-data review, outcome equity audit. Pilot reporting must describe selection bias and whether learning gains are attributable to EducationOS.
