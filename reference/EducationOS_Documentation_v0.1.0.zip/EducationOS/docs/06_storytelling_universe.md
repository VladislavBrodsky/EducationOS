# 06 · Storytelling and creative discovery universe

**Version:** 0.1.0 | **Status:** proposed; to be validated through child/educator research.

## Creative thesis
EducationOS is a world of **questions with consequences**, not a sequence of rewards without meaning. Narrative mission: learners are inventors restoring the connected **Atlas of Possibilities**. Each world presents authentic dilemmas, limited resources, competing stakeholders and scientific mysteries. Players improve the world by gathering evidence, building models and explaining solutions rather than clicking through lectures.

## Story world structure
- **Curiosity Grove (5–6):** nature, shadow, shape, pattern; friendly guide asks questions and encourages off-screen experiments. No urgency or FOMO.
- **Builder Harbor (7–9):** bridges, boats, tools, communities; choose among multiple plausible solutions and investigate.
- **Orbit Lab (10–12):** trajectories, energy, coding, data; measure, predict, construct and debug scientifically accurate models.
- **Future City (13–15):** climate, communications, social impact; navigate contradictions, ethics and stakeholder viewpoints.
- **Frontier Studio (16–17):** open challenges with mentors and capstones; research sources, document versions, present evidence and transfer to new contexts.

Each world has a shared story bible: setting, hero's question, competing constraints, emotional tone, learning objectives, characters, safety checklist, canon illustrations, accepted evidence and end-of-mission reflection. Each mission has 3 levels of scaffolding and a non-digital equivalent where practicable.

## Example story arc: The Bridge That Must Be Both Strong and Light
**Hook:** floating library needs a portable crossing before rain; carrying extra materials risks sinking the boat.
1. Explore bridge function and local resources.
2. State contradiction: more material improves strength **but** increases weight.
3. Draw 3 radically different approaches (divergent phase; no premature criticism).
4. Use TRIZ segmentation, curvature, local quality and another dimension as optional prompts.
5. Make 2 physical prototypes using equal material mass; adult supervises.
6. Test with identical loads; photograph/draw artifacts only with safe consent and private storage.
7. Explain why one design worked, what failed, what to improve, and where principle applies elsewhere.
**Reward:** access to a new narrative question and a private evidence-backed skill card, not an artificially inflated mastery percentage.

## Child-safe motivation and ethical social layer
- Autonomy: real choice of challenge, method and topic; competence: clear feedback; relatedness: trusted guardian/teacher collaboration.
- No public child handles, likes, direct messages, open leaderboards, or viral incentives targeting children.
- Adults may opt into sharing privacy-reviewed project showcases; use guardian-controlled referrals.
- Healthy stopping points, daily break prompts, offline mission options and no manipulative loss aversion.
