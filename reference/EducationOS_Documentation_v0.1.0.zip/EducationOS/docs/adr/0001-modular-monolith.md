# ADR-0001 · Begin with a modular monolith

**Status:** proposed · **Date:** 2026-10-17 · **Decider:** CTO after founder/team review.

**Context:** Product/curriculum and target market are not yet validated, so operational and consistency overhead of microservices is unjustified.

**Decision:** One backend deployment with strongly isolated modules and a separate async worker; PostgreSQL as source of truth; versioned OpenAPI contracts.

**Alternatives:** microservices (too much early coordination), backend-as-a-service-only (limits complex child-safety and mastery rule ownership).

**Consequences:** faster iteration and lower ops burden; requires modular discipline and explicit service boundaries. **Review trigger:** independent teams or load profiles create measurable scaling bottlenecks.
