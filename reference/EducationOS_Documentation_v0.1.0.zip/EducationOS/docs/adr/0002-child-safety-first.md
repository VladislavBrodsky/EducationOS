# ADR-0002 · Child safety as a release dependency

**Status:** proposed · **Date:** 2026-10-17 · **Decider:** CEO, legal/safeguarding lead and CTO.

**Decision:** No real-child enrollment until privacy, age-appropriate consent, object-level permissions, moderation/safeguarding, data deletion, AI controls and incident handling have been reviewed against initial launch jurisdictions.

**Consequences:** restricts MVP velocity by design; lowers material and regulatory risk. **Review trigger:** market expansion or fundamental shift in learner-data purposes.
