# 12 · EducationOS design system

**Version:** 0.1.0 | **Status:** reference design proposals; contrast and usability tests pending.

## Design inputs
16 supplied presentation references with bold near-black sans type, white backgrounds, gray auxiliary text, vivid lime progress/navigation accents, glass-like educational cards, 3D globes/books/labs and spatial orbital elements. External inspiration: https://styles.refero.design/style/75fdb89f-ca64-41b3-af36-7a78bd09448e . Treat this as an independent source, not an exact match for the EducationOS slides; verify rights for any copyrighted artwork and fonts.

## Brand structure
- **Discovery**: learners; bright accents, playful but sophisticated education props, larger touch surfaces, illustrations and age-tunable motion.
- **Editorial**: guardians, educators and investor content; restrained typography, rich explanation and data-dense accessible forms.
- Unified spacing scale, type scale, shape language, state patterns, component APIs and icon family. No decoration that communicates false progress.

## Proposed tokens (not final color-contrast approvals)
```
color.canvas = #FFFFFF
color.ink = #111111
color.muted = #62666B
color.brand.lime = #8DEA26
color.border = #E6E8E4
color.surface = #F8F9F6
radius.card = 20px
radius.control = 12px
space = 4px base grid
motion.reduced = system preference
```
Lime should generally be **decorative, focused or background**; test text/icon contrast separately. Support forced-colors/high-contrast and reduced-motion. Prefer licensable sans and editorial display font pair with full multilingual character support.

## Required component inventory
Button, icon button, input, select, checkbox, dialog, menu, tab, card, mission card, skill chip, learning map, path step, feedback banner, private evidence viewer, consent drawer, guardian approval, reading aid, accessible progress visualization, rubric panel, experiment safety checklist, AR preview fallback, empty/error/offline states and skeleton. Storyworld art should be an optional presentation layer over semantic content.

## Design acceptance
Figma tokens = code tokens; design reviews include all five age stages, English + second launch language, phone/tablet/desktop, touch target sizes, screenreader, keyboard, captions and cognitive load. Story animations should never block comprehension.
