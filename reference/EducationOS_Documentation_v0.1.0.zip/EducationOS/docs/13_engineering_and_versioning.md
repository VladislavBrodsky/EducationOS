# 13 · Engineering governance and version control

**Version:** 0.1.0 | **Status:** proposed governance.

## Repository strategy
Single monorepo for web, API, workers, design tokens, schemas, content tooling and shared packages. Begin as modular monolith; avoid splitting repos and services until clear team/deployment ownership emerges. `/apps/web`, `/apps/api`, `/apps/worker`, `/packages/ui`, `/packages/contracts`, `/packages/config`, `/content`, `/docs`, `/infra`, `/scripts`.

## Branching and releases
Protected `main`. `feature/<ticket>`, `fix/<ticket>`, `docs/<ticket>`; changes via PR with author checklist + reviewer; no direct push to main after governance settings enabled. Conventional commits, mandatory changelog entries for material changes, SemVer for API/application releases; immutably version mission/rubric/prompt content. Maintain `CHANGELOG.md` and tagged releases. This v0.1.0 denotes a **documentation baseline**, not an implemented product or existing Git tag.

## CI quality gates
Typecheck, lint, formatting, unit/component tests, policy tests, DB migration checks, API contract diff, E2E smoke tests, secrets scan, dependency/security scan, accessibility automated check, license check and preview deploy on PR. Protection requires at least one reviewer (two for privacy/security/AI policy) and all required checks green. Production deploys must be auditable, reversible and environment-gated.

## Architecture decisions
RFC when multiple teams or material product strategy changes; ADR for implementation choices. Each ADR: status, context, options, decision, trade-offs, implementation triggers, supersedes link, owner/date. No undocumented irreversible vendor lock-in.

## Definition of done
User story + measurable acceptance criteria, owner, test coverage, a11y verification, privacy/safety check, docs/runbook updated, rollback plan, monitoring and telemetry, QA review. Curriculum missions additionally require expert pedagogy review and safety sign-off.
