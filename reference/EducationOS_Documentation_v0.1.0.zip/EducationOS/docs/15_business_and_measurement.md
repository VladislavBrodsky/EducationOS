# 15 · Business development, go-to-market and metrics

**Version:** 0.1.0 | **Status:** hypotheses; no operating revenue or traction claimed.

## Business thesis
Initially position for parents of curious children seeking active, rigorous project-based learning that teaches creativity, reasoning, science and real-world problem-solving; validate willingness to pay through structured interviews and paid pilots. School distribution comes later when teacher value and safeguarding/compliance are proven.

## Pricing hypotheses to test
B2C family subscription with limited free sample missions, monthly/annual pricing experiments and guardian control. Optional live cohort upsell only after trained educator supply, safeguarding and economics. School seats/licenses with procurement, roster integrations and teacher workflow ROI after pilot. Never monetize child behavioral data; no child-targeted ads, peer-pressure referrals or surprise auto-renewals.

## Social growth operating system
Audience: **adults** (guardians, educators, school leaders), not child accounts. Channels: YouTube long-form demonstrable experiments, Instagram/TikTok founder/educator shorts for adults, LinkedIn educational partnerships, SEO content around inventor-thinking missions, newsletter and webinars. Per content item: learning question, 1-minute demonstration, explicit age suitability and supervision, printable activity, proof or caveat, privacy-safe CTA. Measure meaningful adult intent: qualified waitlist signups, educational resource downloads, pilot conversion and referral quality; do not optimize minutes watched by children.

## Ethical flywheel
Teacher-quality invention missions → parent/educator trust → opt-in pilot/paid enrollment → measurable skill artifacts → educator reviewed story-based case studies (with consent) → more qualified adult discovery and referrals → improved missions. Show evidence and limitations, not manufactured growth charts.

## KPI tree
North star WECD from assessment spec, validated against independent learning gains. Acquisition: adult traffic → qualified waitlist → activation → completed first off/on-screen mission → first authentic evidence → repeat weekly learning with breaks → paid family conversion → survival/retention → referrals. Guardrails: child-safety incidents, consent errors, excessive screen time, harm reports, cognitive load, accessibility task success, parent cancellations, educator workload. Cohort dashboards split by age/context where safe and statistically responsible.

## Fundraising sequence
- **Pre-seed readiness:** founder thesis, defensible content/pedagogy, prototype, compliant pilot readiness, 3-year model with explicit assumptions, clear milestones and use of funds. Investor deck: problem, why now, learner transformation, demo, validation results, competitive differentiation, market sizing method, GTM, team, economics, ask and milestones.
- **Seed readiness:** repeated safe learning outcomes, paid cohort retention, growing organic adult acquisition, unit economics measured, technical defensibility and evidence of a scalable instructional content supply process.
- Data room: cap table, IP assignments, corporate setup, financial plan/runway, demo, technical and curriculum architecture, consent/privacy policies, contracts, cohort metrics with definitions, security issues, risk register, governance and research methodology.
- Non-dilutive grants, school/foundation research partnerships and validated pre-sales can complement equity. Avoid pretending illustrative pitch deck ARR is operating revenue.

## Working economics model
Build a bottom-up spreadsheet *after* target market and pricing are chosen: gross margin = subscription revenue less payment processing, content, AI, storage and support variable costs. Customer acquisition cost by channel, time-to-recover CAC, logo/revenue churn, cohort gross retention, lead-to-paid conversion, capacity per teacher/live cohort and safety moderation costs. Publish conservative/base/upside **assumptions** separately from actuals.
